import ReactDOM from 'react-dom';

import PersonCard from './components/personCard';

ReactDOM.render(
    <PersonCard />,
    document.getElementById('root')
);