import './App.css';
import SomeForm from './components/someForm';


function App() {
  return (
    <div className="App">
      <SomeForm />
    </div>
  );
}

export default App;
