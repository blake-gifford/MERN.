
import SomeForm from './components/someForm';
import './App.css';


function App() {
  return (
    <div className="App">
      <SomeForm />
    </div>
  );
}

export default App;
